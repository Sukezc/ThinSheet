#include"computeWidget.h"
#include"Xml.h"
#include<iostream>
#include<sstream>


void computeKernel(bool saveFlag, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model, std::ofstream& outfile_xy, std::ofstream& outfile_force)
{
	ElementGroup::InitializeTorqueGroup(model.num_iterate);
	bool ResetMatrix;
	Egold = ElementGroup(model); Egnew = ElementGroup(model);
	for (int i = 0; i < model.num_iterate; i++)
	{
		ResetMatrix = Elongate(Egold, Egnew, model);
		deltaS_iterate(Egold, Egnew, model.dt);
		theta_iterate(Egold, Egnew, model.dt);
		H_iterate(Egold, Egnew, model.dt);
		K_iterate(Egnew);
		bodyforce_compute(Egnew);
		surface_force_iterate(Egnew, model, i);
		Omega_Delta_iterate(Egnew, model, SolverHandle, ResetMatrix);
		omega_iterate(Egnew, model);
		velocity_iterate(Egnew, model);
		if (model.SaveEveryXY)
		{
			Egnew.ComputeXY().ComputeGravityTorque(i).ComputePforceTorque(i);
			if (saveFlag) Egnew.SaveXY(outfile_xy).SaveForce(outfile_force);
		}
		else if (!(i % (model.num_iterate / model.num_XY)))
		{
			Egnew.ComputeXY().ComputeGravityTorque(i).ComputePforceTorque(i);
			if (saveFlag) Egnew.SaveXY(outfile_xy).SaveForce(outfile_force);
		}
		std::swap(Egold, Egnew);
	}
	model.ResetGridAndIterating();
}

void computeVarianceRegression(bool saveOrNot, std::pair<double, double>& dampRate_variance, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model, std::ofstream& outfile_xy, std::ofstream& outfile_force)
{
	for (int dampsearchcount = 0; dampsearchcount < model.Dampsearch; dampsearchcount++)
	{
		std::cout << "DampSearchCount  " << dampsearchcount + 1 << " : " << model.Dampsearch << std::endl;
		bool saveFlag;

		if (dampsearchcount == model.Dampsearch - 1)saveFlag = true;
		else saveFlag = false;

		computeKernel(saveOrNot && saveFlag, Egold, Egnew, SolverHandle, model, outfile_xy, outfile_force);
		std::cout << "dampingRate:" << model.dampingrate << "\n";
		std::cout << "variance:" << ElementGroup::ComputeGravityPforceTorqueCovariance() << "\n";
		static double dampingRateinterval = 0.0; static int DRchange = 0;

		if (!dampsearchcount)
		{
			dampRate_variance.first = model.dampingrate;
			dampRate_variance.second = ElementGroup::ComputeGravityPforceTorqueCovariance();
			dampingRateinterval = model.dampingrate * 0.3;
			DRchange = 0;
			model.dampingrate *= 0.7;
		}
		else if (dampsearchcount == model.Dampsearch - 1)break;
		else
		{
			std::pair<double, double> tempDamprate_variance;
			tempDamprate_variance.first = model.dampingrate;
			tempDamprate_variance.second = ElementGroup::ComputeGravityPforceTorqueCovariance();
			if (tempDamprate_variance.first < 0.0 || tempDamprate_variance.second / dampRate_variance.second > 1.0)
			{
				dampingRateinterval *= 0.5;
				model.dampingrate = dampRate_variance.first - dampingRateinterval;
				dampsearchcount--;
				DRchange++;
				if (DRchange == model.Dampsearch)
				{
					dampsearchcount = model.Dampsearch - 2;
					model.dampingrate = dampRate_variance.first;
				}
			}
			else if (fabs(tempDamprate_variance.first - dampRate_variance.first) < 1e-8)
			{
				dampsearchcount = model.Dampsearch - 2;
				model.dampingrate = dampRate_variance.first;
			}
			else
			{
				if (dampsearchcount == model.Dampsearch - 2) model.dampingrate = dampRate_variance.first;
				dampRate_variance.first = tempDamprate_variance.first;
				dampRate_variance.second = tempDamprate_variance.second;
				model.dampingrate -= dampingRateinterval;
			}
		}
	}
	model.ResetDampRate();
}

void computeCriticalAngleRegressionBasedOnVariance(const std::string& filename,std::pair<double, double>& dampRate_variance, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model)
{
#ifdef MY_WINDOWS
	std::string mkdir = "md";
	std::string copy = "copy";
#else
	std::string mkdir = "mkdir";
	std::string copy = "cp";
#endif // MY_WINDOWS
	double VarianceLeft = 0.0, VarianceRight = 0.0,tempVariance = 0.0;
	double CriticalAngleLeft, CriticalAngleRight, CAinterval = 0.0;
	CAinterval = fabs(fabs(model.criticalAngleRange.second) - fabs(model.criticalAngleRange.first))/ model.criticalAngleSegment;
	CriticalAngleLeft = model.criticalAngleRange.first; CriticalAngleRight = CriticalAngleLeft + CAinterval;
	for (int CASegment = 0; CASegment < model.criticalAngleSegment; CASegment++)
	{
		model.criticalAngleRange.first = CriticalAngleLeft;
		model.criticalAngleRange.second = CriticalAngleRight;
		CriticalAngleLeft += CAinterval; CriticalAngleRight += CAinterval;
		for (int anglesearchcount = 0; anglesearchcount < model.criticalRangeCount; anglesearchcount++)
		{
			std::ofstream outfile_placehold;
			if (model.criticalRangeCount > 1 && !anglesearchcount)
			{
				for (int p = 0; p < 2; p++)
				{
					if (!p && !CASegment)
					{
						model.criticalangle = model.criticalAngleRange.first;
						computeVarianceRegression(false, dampRate_variance, Egold, Egnew, SolverHandle, model, outfile_placehold, outfile_placehold);
						VarianceLeft = dampRate_variance.second;
					}
					else if (!p)
					{
						VarianceLeft = tempVariance;
					}
					else
					{
						model.criticalangle = model.criticalAngleRange.second;
						computeVarianceRegression(false, dampRate_variance, Egold, Egnew, SolverHandle, model, outfile_placehold, outfile_placehold);
						tempVariance = VarianceRight = dampRate_variance.second;
					}
				}
				model.criticalangle = (model.criticalAngleRange.first + model.criticalAngleRange.second) / 2.0;
			}
			std::cout << "CriticalAngle:" << fabs(model.criticalangle) << std::endl;
			std::string dir = std::to_string(fabs(model.criticalangle));
			system((mkdir + " " + dir).c_str());
			system((copy + " " + filename + " " + dir).c_str());
			std::ofstream outfile_xy(dir + "/" + model.XYaddress);
			std::ofstream outfile_force(dir + "/" + model.Forceaddress);
			std::ofstream outfile_Torque(dir + "/" + model.Torqueaddress);

			computeVarianceRegression(true, dampRate_variance, Egold, Egnew, SolverHandle, model, outfile_xy, outfile_force);

			vector_save(ElementGroup::GravityTorqueGroup, outfile_Torque);
			vector_save(ElementGroup::PforceTorqueGroup, outfile_Torque);


			std::ifstream fin(dir + "/" + filename);
			std::stringstream ss;
			ss << fin.rdbuf();
			const std::string& str = ss.str();
			xml::Xml root;
			root.parse(str);
			fin.close();
			root["CriticalAngle"].text(std::to_string(model.criticalangle));
			root["DampingRate"].text(std::to_string(dampRate_variance.first));
			root.append(xml::Xml("Varience", std::to_string(dampRate_variance.second)));
			root.save(dir + "/Conf.xml");
			outfile_xy.close();
			outfile_force.close();
			outfile_Torque.close();

			if (model.criticalRangeCount > 1)
			{
				double tempCriticalAngle = model.criticalangle;
				if (fabs(dampRate_variance.second - VarianceLeft) > fabs(dampRate_variance.second - VarianceRight))
				{
					VarianceLeft = dampRate_variance.second;
					model.criticalAngleRange.first = model.criticalangle;
				}
				else
				{
					VarianceRight = dampRate_variance.second;
					model.criticalAngleRange.second = model.criticalangle;
				}
				model.criticalangle = (model.criticalAngleRange.first + model.criticalAngleRange.second) / 2.0;
			}
		}
	}
}