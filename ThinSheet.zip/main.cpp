/*
author:zhang_chuanzhe
coding with: utf-8
email:191830203@smail.nju.edu.cn
last modify date:2022.8.1
*/


/*
����һά��������ϵ�Ķ�ά����Ƭ�˶�ģ��
ϡ���������Ӣΰ��ٷ��ṩ��cusolver��
*/


#include"element_handle.h"
#include"CusolverSpHandle.h"
#include"CusolverRfHandle.h"
#include"element_iterate.h"
#include"ObjFactory.h"
#include"computeWidget.h"
#include<cstdlib>
#include<ctime>
#include<iostream>


int main(int argc, char* argv[])
{
	ModelConf model;
	if (argc != 2) 
	{ 
		exit(-1); 
		std::cout << "Wrong arguments!" << std::endl;
	}
	std::ifstream fin(argv[1]);
	model.load_parameter(fin);
	ElementGroup Egold; ElementGroup Egnew;
	fin.close();

	model.Debug();
	
	REGISTER(CusolverRfHandle)
	REGISTER(CusolverSpHandle)
	SolverInterface* SolverHandle = NULL;

	if (model.solver == Solver::RF) SolverHandle = ObjFactory::Instance().CreateObj<SolverInterface>("CusolverRfHandle");
	else if (model.solver == Solver::SP) 
	{
		SolverHandle = ObjFactory::Instance().CreateObj<SolverInterface>("CusolverSpHandle");
		reinterpret_cast<CusolverSpHandle*>(SolverHandle)->solution = model.solution;
	}
	
	std::pair<double, double> dampRate_variance;
	computeCriticalAngleRegressionBasedOnVariance(argv[1],dampRate_variance,Egold,Egnew,SolverHandle,model);

	delete SolverHandle;
	return 0;
}



