#include "Xml.h"
#include "Parser.h"
#include<iostream>
using namespace xml;

#include <fstream>
#include <sstream>

Value::Value()
{
}

Value::Value(bool value)
{
    *this = value;
}

Value::Value(int value)
{
    *this = value;
}

Value::Value(double value)
{
    *this = value;
}

Value::Value(const char * value) : m_value(value)
{
}

Value::Value(const std::string & value) : m_value(value)
{
}

Value::~Value()
{
}

Value & Value::operator = (bool value)
{
    m_value = value ? "true" : "false";
    return *this;
}

Value & Value::operator = (int value)
{
    std::stringstream ss;
    ss << value;
    m_value = ss.str();
    return *this;
}

Value & Value::operator = (double value)
{
    std::stringstream ss;
    ss << value;
    m_value = ss.str();
    return *this;
}

Value & Value::operator = (const char * value)
{
    m_value = value;
    return *this;
}

Value & Value::operator = (const std::string & value)
{
    m_value = value;
    return *this;
}

Value & Value::operator = (const Value & value)
{
    m_value = value.m_value;
    return *this;
}

bool Value::operator == (const Value & other)
{
    return m_value == other.m_value;
}

bool Value::operator != (const Value & other)
{
    return !(m_value == other.m_value);
}

Value::operator bool()
{
    if (m_value == "true")
        return true;
    else if (m_value == "false")
        return false;
    return false;
}

Value::operator int()
{
    return std::atoi(m_value.c_str());
}

Value::operator double()
{
    return std::atof(m_value.c_str());
}

Value::operator std::string()
{
    return m_value;
}

Xml::Xml() : m_name(nullptr), m_text(nullptr), m_attrs(nullptr), m_child(nullptr)
{
}

Xml::Xml(const char * name) : m_name(nullptr), m_text(nullptr), m_attrs(nullptr), m_child(nullptr)
{
    m_name = new std::string(name);
}

Xml::Xml(const std::string & name) : m_name(nullptr), m_text(nullptr), m_attrs(nullptr), m_child(nullptr)
{
    m_name = new std::string(name);
}

Xml::Xml(const Xml & other)
{
    m_name = other.m_name;
    m_text = other.m_text;
    m_attrs = other.m_attrs;
    m_child = other.m_child;   
}

Xml::Xml(const std::string& name, const std::string& text):m_attrs(nullptr), m_child(nullptr)
{
    m_name = new std::string(name);
    m_text = new std::string(text);
}

std::string Xml::name() const
{
    if (m_name == nullptr)
    {
        return "";
    }
    return *m_name;
}

void Xml::name(const std::string & name)
{
    if (m_name != nullptr)
    {
        delete m_name;
    }
    m_name = new std::string(name);
}

std::string Xml::text() const
{
    if (m_text == nullptr)
    {
        return "";
    }
    return *m_text;
}

void Xml::text(const std::string & text)
{
    if (m_text != nullptr)
    {
        delete m_text;
    }
    m_text = new std::string(text);
}

Value & Xml::attr(const std::string & key)
{
    if (m_attrs == nullptr)
    {
        m_attrs = new std::map<std::string, Value>();
    }
    return (*m_attrs)[key];
}

void Xml::attr(const std::string & key, const Value & value)
{
    if (m_attrs == nullptr)
    {
        m_attrs = new std::map<std::string, Value>();
    }
    (*m_attrs)[key] = value;
}

Xml & Xml::operator = (const Xml & other)
{
    clear();
    m_name = other.m_name;
    m_text = other.m_text;
    m_attrs = other.m_attrs;
    m_child = other.m_child;
    return *this;
}

void Xml::append(const Xml & child)
{
    if (m_child == nullptr)
    {
        m_child = new std::list<Xml>();
    }
    m_child->push_back(child);
}

Xml & Xml::operator [] (int index)
{
    if (index < 0)
    {
        throw std::logic_error("index less than zero");
    }
    if (m_child == nullptr)
    {
        m_child = new std::list<Xml>();
    }
    int size = m_child->size();
    if (index >= 0 && index < size)
    {
        auto it = m_child->begin();
        for (int i = 0; i < index; i++)
        {
            it++;
        }
        return *it;
    }
    if (index >= size)
    {
        for (int i = size; i < index; i++)
        {
            m_child->push_back(Xml());
        }
    }
    return m_child->back();
}

Xml & Xml::operator [] (const char * name)
{
    return (*this)[std::string(name)];
}

Xml & Xml::operator [] (const std::string & name)
{
    if (m_child == nullptr)
    {
        m_child = new std::list<Xml>();
    }
    for (auto it = m_child->begin(); it != m_child->end(); it++)
    {
        if (it->name() == name)
        {
            return *it;
        }
    }
    m_child->push_back(Xml(name));
    return m_child->back();
}

void Xml::remove(int index)
{
    if (m_child == nullptr)
    {
        return;
    }
    int size = m_child->size();
    if (index < 0 || index >= size)
    {
        return;
    }
    auto it = m_child->begin();
    for (int i = 0; i < index; i++)
    {
        it++;
    }
    it->clear();
    m_child->erase(it);
}

void Xml::remove(const char * name)
{
    return remove(std::string(name));
}

void Xml::remove(const std::string & name)
{
    for (auto it = m_child->begin(); it != m_child->end();)
    {
        if (it->name() == name)
        {
            it->clear();
            it = m_child->erase(it);
        }
        else
        {
            it++;
        }
    }
}

bool Xml::check(const char* name)
{
    return check(std::string(name));
}

bool Xml::check(const std::string& name)
{
    if (m_child != nullptr)
    {
        for (auto it = m_child->begin(); it != m_child->end(); it++)
        {
            if (it->name() == name)return true;
        }
    }
    return false;
}

int Xml::size() const
{
    if (m_child == nullptr)
    {
        return 0;
    }
    return m_child->size();
}

void Xml::clear()
{
    if (m_name != nullptr)
    {
        delete m_name;
        m_name = nullptr;
    }
    if (m_text != nullptr)
    {
        delete m_text;
        m_text = nullptr;
    }
    if (m_attrs != nullptr)
    {
        delete m_attrs;
        m_attrs = nullptr;
    }
    if (m_child != nullptr)
    {
        for (auto it = m_child->begin(); it != m_child->end(); it++)
        {
            it->clear();
        }
        delete m_child;
        m_child = nullptr;
    }
}

std::string Xml::str(int depth) const
{
    if (m_name == nullptr)
    {
        return "";
    }
    std::ostringstream os;
    for (int i = 0; i < depth; i++) { os << "    "; }
    os << "<";
    os << *m_name;
    if (m_attrs != nullptr)
    {
        for (auto it = m_attrs->begin(); it != m_attrs->end(); it++)
        {
            os << " " << it->first << "=\"" << (std::string)(it->second) << "\"";
        }
    }
    os << ">"; if (m_text == nullptr)os << "\n";
    if (m_child != nullptr)
    {
        for (auto it = m_child->begin(); it != m_child->end(); it++)
        {
            os << it->str(depth+1);
        }
    }
    if (m_text != nullptr)
    {
        os << *m_text;
    }
    if (m_text == nullptr) { for (int i = 0; i < depth; i++) { os << "    "; }; }
    os << "</" << *m_name << ">"; os << "\n";
    return os.str();
}

bool Xml::load(const std::string & filename)
{
    Parser p;
    if (!p.load_file(filename))
    {
        return false;
    }
    *this = p.parse();
    return true;
}

bool Xml::save(const std::string & filename)
{
    std::ofstream fout(filename);
    if (fout.fail())
    {
        return false;
    }
    fout << str(0);
    fout.close();
    return true;
}

bool Xml::parse(const std::string & str)
{
    Parser p;
    if (!p.load_string(str))
    {
        return false;
    }
    *this = p.parse();
    return true;
}