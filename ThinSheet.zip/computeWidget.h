#pragma once
#include"element_handle.h"
#include"element_iterate.h"
#include"SolverInterface.h"
#define MY_WINDOWS 

void computeKernel(bool saveFlag, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model, std::ofstream& outfile_xy, std::ofstream& outfile_force);

void computeVarianceRegression(bool saveOrNot, std::pair<double, double>& dampRate_variance, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model, std::ofstream& outfile_xy, std::ofstream& outfile_force);

void computeCriticalAngleRegressionBasedOnVariance(const std::string& configuration, std::pair<double, double>& dampRate_variance, ElementGroup& Egold, ElementGroup& Egnew, SolverInterface* SolverHandle, ModelConf& model);

