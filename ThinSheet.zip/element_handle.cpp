#include"element_handle.h"

std::vector<double> ElementGroup::GravityTorqueGroup;
std::vector<double> ElementGroup::PforceTorqueGroup;
